
This empty directory has been added so that we can hit [this line](https://codecov.io/gh/mitmproxy/mitmproxy/src/ba13fda10d3065a0c8dfd95d55680675b3bf08c2/mitmproxy/console/pathedit.py#L43) while testing pathedit completion.
