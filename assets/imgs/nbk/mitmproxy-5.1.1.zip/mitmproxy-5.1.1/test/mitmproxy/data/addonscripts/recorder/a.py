import recorder

addons = [recorder.Recorder("a")]
